package me;

public class Warehouse {

	public String[] getLatLng() {
		// TODO Auto-generated method stub
		return null;
	}

	public int getId() {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean soddisfabile(Ordine ordine) {
		// TODO FARE POP
		return false;
	}
	
}
