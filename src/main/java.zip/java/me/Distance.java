package me;

public class Distance {

	public long getDistance() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getOrdineId() {
		// TODO Auto-generated method stub
		return 0;
	}

}
