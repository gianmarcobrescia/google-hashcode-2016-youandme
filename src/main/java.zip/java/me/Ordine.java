package me;

public class Ordine {

	public boolean notEmpty() {
		// TODO Auto-generated method stub
		return false;
	}

	public long pop() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void push(long prodid) {
		// TODO Auto-generated method stub
		
	}

}
